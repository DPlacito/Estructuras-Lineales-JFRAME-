package Bicola;

import Bicola.Nodo;
import Bicola.Clientes;

public class BicolaClientes {

    public Nodo fin, inicio;
    public int numDeNodos;

    public BicolaClientes() {
        fin = inicio = null;
    }

    /* public static void main (String[] args) {
   Nodo cola = new Nodo();
   BicolaClientes obj = new BicolaClientes();
    Clientes cliente1 = new Clientes("izquierda1","izquierda","izquierda",9809809);
    Clientes cliente2 = new Clientes("derecha1","derecha","derecha",9809809);
    Clientes cliente3 = new Clientes("izquierda2","izquierda","izquierda",9809809);
    Clientes cliente4 = new Clientes("derecha2","derecha","derecha",9809809);
    obj.addDatoIzquierda(cliente1);//izquierda
    obj.addDatoDerecha(cliente2);//derecha
    obj.addDatoIzquierda(cliente3);//izquierda
    obj.addDatoDerecha(cliente4);//derecha
    obj.toString();
    obj.getDatoIzquierda();
    obj.toString();
    obj.getDatoDerecha();
    obj.toString();
 }  
     */
    public int getNumDeNodos() {
        return numDeNodos;
    }

    public void addDatoIzquierda(Clientes c)//inicio
    {

        Nodo temp = new Nodo(c);

        if (inicio == null) {
            inicio = fin = temp;
        } else {
            temp.setSig(inicio);//posicionas el temp en el siguiente para mover el inicio
            inicio.setAnt(temp); // posicionas el inicio en el anterior para setear el temp que es el nuevo nodo
            inicio = temp; // actualizas la variale de inicio para que apunte a temporal
        }
        numDeNodos++;
    }

    public void addDatoDerecha(Clientes c)//fin
    {
        Nodo temp = new Nodo(c);

        if (fin == null) {
            fin = inicio = temp;
        } else {
            temp.setAnt(fin);//posicionas el elemento en el anterior para que fin  se recorra una posicion atras
            fin.setSig(temp);//seteas el valor siguiente de fin a la variable temporal que es nuevo nodo
            fin = temp; // actualizar el valor de la variable fin al valor entrante de nodo
        }
        numDeNodos++;
    }

    // Extrae el primer dato y cambia las referenciaas de las propiedades.
    public boolean getDatoIzquierda()//eliminar por el inicio
    {
        Clientes temp = inicio.getA();

        if (inicio == fin) // Solo hay un nodo y se acaba de extraer quedando ahora 0.
        {
            inicio = fin = null;
            return true;
        } else {
            inicio = inicio.getSig();// posicionas a inicio en la siguiente posiciion para desreferenciar
            inicio.setAnt(null); //seteas el valor anterior a inicio a NULL y con eso se desreferencia y se borra
            return true;

        }
        //numDeNodos--;
    }
     
    // Extrae el ultimo dato y cambia las referenciaas de las propiedades.
    public boolean getDatoDerecha()//eliminar por el final
    {
        Clientes temp = fin.getA();

        if (inicio == fin) {
            inicio = fin = null;
            return true;
        } else {
            fin = fin.getAnt(); //posiciionas a fin en el valor anterior
            fin.setSig(null);//seteas a nulo el valor siguiente de fin para que desreferencie el ultimo valor
            return true;
        }

        //numDeNodos--;
// return temp;
    }

    public Nodo getFin() {
        return fin;
    }

    public Nodo getInicio() {
        return inicio;
    }

    // Concatena todos los elementos de la Bicola por referencias y lo retorna.
    public String toString() {
        String cadena = "";
        Nodo posicion = inicio;

        while (posicion != null) {
            System.out.println("Elemento " + posicion + " es " + posicion.getA().getNoCuenta());
            cadena += posicion.getA() + ", ";
            posicion = posicion.getSig();
        }

        return cadena;
    }
}