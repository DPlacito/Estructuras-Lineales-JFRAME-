package Bicola;

public class Nodo {
    public Clientes a;
     public Nodo sig,ant;

    public Nodo() {
    }
     

    public Nodo(Clientes a) {
        this.a = a;
        this.sig=null;
    }

    public Clientes getA() {
        return a;
    }

    public void setA(Clientes a) {
        this.a = a;
    }

    public Nodo getSig() {
        return sig;
    }

    public void setSig(Nodo sig) {
        this.sig = sig;
    }

    public Nodo getAnt() {
        return ant;
    }

    public void setAnt(Nodo ant) {
        this.ant = ant;
    }
     
}

