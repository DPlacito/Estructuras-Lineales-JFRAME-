/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cola_Clientes;

/**
 *
 * @author Daniel Arturo Gonzalez Placito
 */
public class Clientes {
    public String noCuenta,nombre,rfc;
    public int telefono;

    public Clientes(String noCuenta, String nombre, String rfc, int telefono) {
        this.noCuenta = noCuenta;
        this.nombre = nombre;
        this.rfc = rfc;
		this.telefono = telefono;
    }

	public String getNoCuenta() {
		return noCuenta;
	}

	public void setNoCuenta(String noCuenta) {
		this.noCuenta = noCuenta;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getRfc() {
		return rfc;
	}

	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}
}