/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cola_Clientes;

import static javax.swing.JOptionPane.showMessageDialog;

/**
 *
 * @author Daniel Arturo Gonzalez Placito
 */
public class ColaClientes {
    public int  tam,tope;
    public Clientes A1[];

    public ColaClientes() {
        tam=0;tope=-1;
    }
    public ColaClientes(int t) {
        tam=t;tope=-1;
        A1=new Clientes[tam];
    }
    public boolean estaVacia(){return tope==-1;}
    public boolean estaLlena(){return tope==tam-1;}
    public void entrada(String noCuenta,String nombre, String rfc, int telefono){
        if(!estaLlena()) A1[++tope]=new Clientes(noCuenta,nombre,rfc,telefono);
        else showMessageDialog(null,"Cola Llena");
    }
    public Clientes salida(){
        if(!estaVacia())return A1[tope--];
        else showMessageDialog(null,"Cola Vacia");
        return null;
    }

	public int getTam() {
		return tam;
	}

	public void setTam(int tam) {
		this.tam = tam;
	}

	public int getTope() {
		return tope;
	}

	public void setTope(int tope) {
		this.tope = tope;
	}

	public Clientes[] getA1() {
		return A1;
	}

	public void setA1(Clientes[] A1) {
		this.A1 = A1;
	} 
}