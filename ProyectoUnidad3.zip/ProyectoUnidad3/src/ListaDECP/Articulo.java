/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaDECP;

import ListaDoblementeEnlazada.*;



/**
 *
 * @author Daniel Arturo Gonzalez Placito
 */
public class Articulo { 
    public String clave;
    public String descripcion;
    public Float precio;
    
    
    public Articulo(String clave, String descripcion, float precio) {
       this.clave = clave;
       this.descripcion = descripcion;
       this.precio = precio;
    }
    Articulo() {
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "\n" +"Clave: " + clave + "\n"+"Nombre: " + descripcion +"\n"+"--------------------------------";
    }

   
}
