package ListaDECP;
import ListaDECP.*;
import Menu_Principal.pantallaPrincipal;
import java.awt.Component;
import java.util.Vector;
import static javax.swing.JOptionPane.*;

public class ListaDEC extends javax.swing.JFrame {

   // Vector<Object>Listasexo;
    Vector<Object>listaNodo;
    public void setLocationRelativeto(Component c){
        super.setLocationRelativeTo(c);
    }
    public ListaDEC() {
        initComponents();
       listaNodo=new Vector<Object>();
       listasElementos();
       listaMetodos();
       setLocationRelativeTo(null);
       ComboBox_Operaciones.setEnabled(false);
       BotonAgregar2.setEnabled(false);
       BotonBuscar.setEnabled(false);
       btnMostrar.setEnabled(false);
       btnEliminarlista.setEnabled(false);
      
    }
    ListasSimples a=new ListasSimples();
       
    public void agregarElementos(){
        Articulo c=new Articulo(txt_Codigo.getText(),txt_Descripcion.getText(), 0);
        a.insertar(c);
        limpiar();
        jSPGraficos.setViewportView(new PaintDibujo(a.tamañoLista(),"d",a));
        
    }
    public void listasElementos(){
        jTextArea1.setText(a.presentar());   
        jSPGraficos.setViewportView(new PaintDibujo(a.tamañoLista(),"d",a));
    }
    
    public void listaMetodos(){
        listaNodo.add("Inserta Inicio");
        listaNodo.add("Inserta Fin");
        listaNodo.add("Eliminar Inicio");
        listaNodo.add("Eliminar Fin");
        listaNodo.add("Inserta entre Nodos");
        listaNodo.add("Eliminar entre Nodos");
        for(int i=0;i<listaNodo.size();i++){
            ComboBox_Operaciones.addItem(listaNodo.get(i));
        } 
    }
    public void eliminar(){
        a.eliminarlista();
        jSPGraficos.setViewportView(new PaintDibujo(a.tamañoLista(), "d", a));
        jTextArea1.setText(null);
    }
    public void Operacion(){
        if(ComboBox_Operaciones.getSelectedItem().equals("Eliminar Inicio")){
           try{
            a.eliminarInicio();
            jSPGraficos.setViewportView(new PaintDibujo(a.tamañoLista(),txt_Codigo.getText(), a));
           }catch(NullPointerException ex){
           showMessageDialog(null,"Necesitas Mas De Dos Elementos En La Lista");
           } 
        }if(ComboBox_Operaciones.getSelectedItem().equals("Inserta Inicio")){
            try{
            Articulo c=new Articulo(txt_Codigo.getText(),txt_Descripcion.getText(), 0);
            a.insertaInicio(c);
            limpiar();
            jSPGraficos.setViewportView(new PaintDibujo(a.tamañoLista(), txt_Codigo.getText(), a));
        showMessageDialog(this, "La Operacion Se Realizo Con Exito");
            }
            catch(Exception ex)
            {showMessageDialog(null,"Favor de introducir valores en las cajas de texto");}
        }if(ComboBox_Operaciones.getSelectedItem().equals("Inserta Fin")){
            agregarElementos();
        }if(ComboBox_Operaciones.getSelectedItem().equals("Eliminar Fin")){
           
            a.eliminaFin();
            jSPGraficos.setViewportView(new PaintDibujo(a.tamañoLista(), "d", a));
           
        }if(ComboBox_Operaciones.getSelectedItem().equals("Inserta entre Nodos")){
            int b=Integer.parseInt(showInputDialog("Por favor inserte la posicion que quiere insertar"));
         Articulo c=new Articulo(txt_Codigo.getText(),txt_Descripcion.getText(), 0);
            //   Cliente c=new Cliente(txtcedula.getText(),txt_Descripcion.getText(),txt_Codigo.getText(),itemsexo.getSelectedItem().toString(),txtedad.getText());
            a.insertaEntreNodos(c,b);
            limpiar();
            jSPGraficos.setViewportView(new PaintDibujo(a.tamañoLista(), "d", a));
        }if(ComboBox_Operaciones.getSelectedItem().equals("Eliminar entre Nodos")){
            int b=Integer.parseInt(showInputDialog("Por favor elija la posicion que desea eliminar"));
            a.eliminarEntreNodos(b);
            jSPGraficos.setViewportView(new PaintDibujo(a.tamañoLista(), "d", a));
        }
    }
    public void elminalista(){
        a.eliminarlista();
        jSPGraficos.setViewportView(new PaintDibujo(a.tamañoLista(), "d", a));
    }
    public void buscarElementos(){
       try{
        String mens=showInputDialog("Ingrese la clave del elemento que desea buscar: ");
        if(mens != null){
            int resp = Integer.parseInt(mens);  
           
            showMessageDialog(null, "EL VALOR SE ENCONTRÓ EN LA LISTA Y ES:" +"\n" +a.buscarNodoIndice(resp).info);
            
                //showMessageDialog(null, "Ingrese posicion correcta\n el tamaño de la lista es:" + a.tamañoLista());
        }
        else{
            showMessageDialog(null, "Ingrese la clave");
        }
       }catch(NullPointerException ex){
       showMessageDialog(null, "Ingrese posicion correcta\n el tamaño de la lista es:" + a.tamañoLista());
       }
    }
    public void limpiar(){
        txt_Codigo.setText(null);
        txt_Descripcion.setText(null);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnBuscar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        itemsexo = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtedad = new javax.swing.JTextField();
        txtcedula = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        btnLimpiar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jSPGraficos = new javax.swing.JScrollPane();
        btnEliminarlista = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        btnMostrar = new javax.swing.JButton();
        ComboBox_Operaciones = new javax.swing.JComboBox();
        BotonAgregar2 = new javax.swing.JButton();
        btnAgregar = new javax.swing.JButton();
        Separador_Codigo = new javax.swing.JSeparator();
        txt_Codigo = new javax.swing.JTextField();
        Separador_Descripcion = new javax.swing.JSeparator();
        txt_Descripcion = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        BotonBuscar = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        jLabel5.setText("Sexo");

        itemsexo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemsexoActionPerformed(evt);
            }
        });

        jLabel6.setText("Edad");

        jLabel2.setText("Cedula");

        txtcedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcedulaActionPerformed(evt);
            }
        });

        jLabel7.setText("Operaciones");

        jLabel1.setText("jLabel1");

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(238, 236, 219));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setBackground(new java.awt.Color(197, 154, 111));
        jLabel8.setFont(new java.awt.Font("Ubuntu", 1, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(32, 47, 90));
        jLabel8.setText("LISTA DOBLEMENTE ENLAZADA CIRCULAR");
        jLabel8.setToolTipText("");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, 810, -1));

        jPanel2.setBackground(new java.awt.Color(102, 0, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 510, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 40, 510));

        jPanel3.setBackground(new java.awt.Color(204, 0, 0));

        jSPGraficos.setBackground(new java.awt.Color(255, 255, 255));
        jSPGraficos.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));

        btnEliminarlista.setText("Eliminar Lista");
        btnEliminarlista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarlistaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(btnEliminarlista)
                        .addGap(407, 407, 407))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jSPGraficos, javax.swing.GroupLayout.PREFERRED_SIZE, 880, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jSPGraficos, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnEliminarlista)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, 920, 220));

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jPanel4.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 40, 350, 180));

        btnMostrar.setText("Mostrar");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });
        jPanel4.add(btnMostrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 10, -1, -1));
        jPanel4.add(ComboBox_Operaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 50, 240, -1));

        BotonAgregar2.setBackground(new java.awt.Color(0, 204, 51));
        BotonAgregar2.setText("Aceptar");
        BotonAgregar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonAgregar2ActionPerformed(evt);
            }
        });
        jPanel4.add(BotonAgregar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 80, -1, -1));

        btnAgregar.setBackground(new java.awt.Color(0, 102, 204));
        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });
        jPanel4.add(btnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, -1, -1));

        Separador_Codigo.setBackground(new java.awt.Color(32, 47, 90));
        jPanel4.add(Separador_Codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 170, 10));

        txt_Codigo.setBackground(new java.awt.Color(240, 240, 240));
        txt_Codigo.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        txt_Codigo.setBorder(null);
        txt_Codigo.setDisabledTextColor(new java.awt.Color(240, 240, 240));
        txt_Codigo.setOpaque(false);
        txt_Codigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_CodigoActionPerformed(evt);
            }
        });
        jPanel4.add(txt_Codigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 30, 170, 40));

        Separador_Descripcion.setBackground(new java.awt.Color(32, 47, 90));
        Separador_Descripcion.setForeground(new java.awt.Color(32, 47, 90));
        Separador_Descripcion.setAutoscrolls(true);
        jPanel4.add(Separador_Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 100, 170, 10));

        txt_Descripcion.setBackground(new java.awt.Color(240, 240, 240));
        txt_Descripcion.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        txt_Descripcion.setBorder(null);
        txt_Descripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_DescripcionActionPerformed(evt);
            }
        });
        jPanel4.add(txt_Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 70, 170, 40));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/icons8_Pencil_Drawing_30px.png"))); // NOI18N
        jPanel4.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/icons8_QR_Code_30px.png"))); // NOI18N
        jPanel4.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 30, -1, -1));

        BotonBuscar.setBackground(new java.awt.Color(255, 204, 0));
        BotonBuscar.setText("Buscar");
        BotonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonBuscarActionPerformed(evt);
            }
        });
        jPanel4.add(BotonBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 160, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/icons8_Search_30px_1.png"))); // NOI18N
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 160, -1, 30));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 60, 920, 230));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Iconos/icons8_Go_Back_40px.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 10, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
      
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void itemsexoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemsexoActionPerformed
        // TODO add your handling code here

    }//GEN-LAST:event_itemsexoActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        // TODO add your handling code here:
        limpiar();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed

    }//GEN-LAST:event_btnModificarActionPerformed

    private void txtcedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcedulaActionPerformed
        // TODO add your handling code here:
        jLabel1.requestFocus();
    }//GEN-LAST:event_txtcedulaActionPerformed

    private void btnEliminarlistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarlistaActionPerformed
        // TODO add your handling code here:
        eliminar();
    }//GEN-LAST:event_btnEliminarlistaActionPerformed

    private void BotonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonBuscarActionPerformed
        buscarElementos();
    }//GEN-LAST:event_BotonBuscarActionPerformed

    private void txt_DescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_DescripcionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_DescripcionActionPerformed

    private void txt_CodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_CodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_CodigoActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed

        agregarElementos();
        showMessageDialog(this, "Se Agrego El Articulo Correctamente");
        //btnAgregar.setEnabled(false);
          ComboBox_Operaciones.setEnabled(true);
       BotonAgregar2.setEnabled(true);
       BotonBuscar.setEnabled(true);
          btnMostrar.setEnabled(true);
       btnEliminarlista.setEnabled(false);
       BotonBuscar.setEnabled(true);
       btnEliminarlista.setEnabled(true);
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void BotonAgregar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonAgregar2ActionPerformed
        // TODO add your handling code here:
        Operacion();
    }//GEN-LAST:event_BotonAgregar2ActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        // TODO add your handling code here:
        listasElementos();
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.setVisible(false);
        new pantallaPrincipal().setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
     
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ListaDEC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ListaDEC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ListaDEC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ListaDEC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListaDEC().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonAgregar2;
    private javax.swing.JButton BotonBuscar;
    private javax.swing.JComboBox ComboBox_Operaciones;
    private javax.swing.JSeparator Separador_Codigo;
    private javax.swing.JSeparator Separador_Descripcion;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminarlista;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JComboBox itemsexo;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jSPGraficos;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField txt_Codigo;
    private javax.swing.JTextField txt_Descripcion;
    private javax.swing.JTextField txtcedula;
    private javax.swing.JTextField txtedad;
    // End of variables declaration//GEN-END:variables
}
