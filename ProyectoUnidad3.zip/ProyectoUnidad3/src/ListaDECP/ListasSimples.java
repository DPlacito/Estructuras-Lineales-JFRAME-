/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaDECP;

import ListaDoblementeEnlazada.*;
import javax.swing.JOptionPane;
/**
 *
 * @author Usuario
 */
public class ListasSimples {
    private NodoDE nodo;
    public ListasSimples(){
        this.nodo=null;
    }
    public boolean esVacia(){
        if(nodo==null){
            return true;
        }else{
            return false;
        }
    }
    public void insertar(Articulo info){
        NodoDE nuevo=new NodoDE(info);
        if(esVacia()){
            nodo=nuevo;
        }else{
            NodoDE aux=nodo;
            while(aux.getSiguiente()!=null){
                aux=aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
        }
    }
    public void insertaInicio(Articulo info){
        if(!esVacia()){
            NodoDE nuevo=new NodoDE(info);
            nuevo.setSiguiente(nodo);
            nodo=nuevo;
        }
    }
     public void eliminarlista(){
        if(!esVacia()){
            nodo.setSiguiente(null);
            nodo=null;
        }
    }
    public String presentar(){
        String texto="";
        NodoDE aux=nodo;
        while(aux!=null){
            texto +=aux.getInfo()+"\n";
            System.out.println(texto+"\n");
            aux=aux.getSiguiente();
        }
        return texto;
    }
    public void pantalla(){
        NodoDE aux=nodo;
        while(aux!=null){
            System.out.println(aux.getInfo());
            aux=aux.getSiguiente();
        }
    } 
    public void eliminarInicio(){
        if(!esVacia()){
            nodo=nodo.getSiguiente();
        }
    }
    public void insertaFin(Articulo info){
        if(!esVacia()){
            NodoDE nuevo=new NodoDE(info);
            NodoDE aux=nodo;
            while(aux.getSiguiente()!= null){
                aux=aux.getSiguiente();
            }
            aux.setSiguiente(nuevo);
            nuevo.setSiguiente(null);
        }
    }
    public void eliminaFin(){
        if(!esVacia()){
            NodoDE aux=nodo;
            while(aux.getSiguiente().getSiguiente()!=null){
                aux=aux.getSiguiente();
            }
            aux.setSiguiente(null);
        }
    }
    public int tamañoLista(){
        NodoDE aux=nodo;
        int cont=0;
        if(!esVacia()){
            cont++;
            while(aux.siguiente!=null){
                cont++;
                aux=aux.siguiente;
        } 
        }
        return cont;
    }
    public void insertaEntreNodos(Articulo info,int pos){
        if(!esVacia()){
            NodoDE nuevo=new NodoDE(info);
            NodoDE aux=nodo;
            NodoDE aux2=aux;
            int pos_recorrido=0;
            if(pos==0){
                insertaInicio(info);
            }
            if(pos==tamañoLista()){
            insertaFin(info);
        }
        if(pos>0 && pos<tamañoLista()){
            while(pos_recorrido != pos ){
                aux2=aux;
                aux=aux.getSiguiente();    
                pos_recorrido++;
            }
           nuevo.setSiguiente(aux);
           aux2.setSiguiente(nuevo);
        }
        }
    }
    public void eliminarEntreNodos(int c){
        int pos=buscarNodo(c);
        if(!esVacia()){
            NodoDE aux=nodo;
            NodoDE aux2=aux;
            int pos_recorrido=0;
            if(pos==0){
                eliminarInicio();
            }else if(pos==tamañoLista()){
                eliminaFin();
            }else if(pos>0 && pos<tamañoLista()){
                while(pos_recorrido!=pos){
                    aux2=aux;
                    aux=aux.getSiguiente();
                    pos_recorrido++;
                }
                aux2.setSiguiente(aux.getSiguiente());
            }
        }
    }
    public void buscar(int pos){
        NodoDE aux=nodo;
        int recorrido=0;
        if(!esVacia()){
            if(pos==0){
                JOptionPane.showMessageDialog(null,"El valor de la Posicion es "+pos+" y los datos son: "+aux.info);
            }else {
                if (pos == tamañoLista()) {
                    while (aux != null) {                        
                        aux = aux.siguiente;
                    }
                    JOptionPane.showMessageDialog(null, "EL VALOR DE LA POSICION " + pos + " ES:" + aux.info);
                } else {
                    if (pos > 0 & pos < tamañoLista()) {
                        while (recorrido != (pos - 1)) {
                            aux = aux.getSiguiente();
                            recorrido++;
                        }
                        JOptionPane.showMessageDialog(null, "EL VALOR DE LA POSICION " + pos + " ES:" + aux.siguiente.info);
                        aux.siguiente = aux.siguiente.siguiente;

                    }
                }
            }
        }
        
        
        
    }
    
    public NodoDE buscarNodoIndice(int indice){
		NodoDE aux = nodo;
		int tamano = 1;
	    while(aux!= null){
	    	if(indice==Integer.parseInt(aux.info.getClave()))
	    		return aux;
	    	aux = aux.siguiente;
	    	tamano++;
	    }
		return null;
	}
    
    public int buscarNodo(int indice){
		NodoDE aux = nodo;
		int tamano = 0;
	    while(aux!= null){
	    	if(indice==Integer.parseInt(aux.info.getClave()))
	    		return tamano;
	    	aux = aux.siguiente;
	    	tamano++;
	    }
		return 0;
	}
    
    public NodoDE get(int posicion){
        NodoDE aux = nodo;
        int contador=0;
        while(contador != posicion){
            aux = aux.getSiguiente();
            contador++;
        }
        return aux;
    }
    public void modificar(int pos, Articulo nuevodato){
        if(!esVacia()){
            NodoDE aux=nodo;
            int pos_recorrido=0;
            while(pos_recorrido!=pos){
                aux=aux.siguiente;
                pos_recorrido++;
            }
            aux.info=nuevodato;
        }
    }
    
}
