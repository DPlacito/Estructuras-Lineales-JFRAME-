/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaDoblementeEnlazada;

/**
 *
 * @author Usuario
 */
public class NodoDE {
    public Articulo info;
    public NodoDE siguiente;
    public NodoDE(Articulo info){
        this.info=info;
        siguiente=null;
    }
 
    
    public Object getInfo() {
        return info;
    }

    public void setDato(Articulo info) {
        this.info = info;
    }

    public NodoDE getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoDE siguiente) {
        this.siguiente = siguiente;
    }   
}