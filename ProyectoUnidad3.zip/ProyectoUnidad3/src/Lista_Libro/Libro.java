package Lista_Libro;

public class Libro {
    public String ISBN,Nombre;
    public int  Precio;

    public Libro() {
    }

    public Libro(String ISBN, String Nombre, int Precio) {
        this.ISBN = ISBN;
        this.Nombre = Nombre;
        this.Precio = Precio;
    }

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String ISBN) {
		this.ISBN = ISBN;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String Nombre) {
		this.Nombre = Nombre;
	}

	public int getPrecio() {
		return Precio;
	}

	public void setPrecio(int Precio) {
		this.Precio = Precio;
	}
}
