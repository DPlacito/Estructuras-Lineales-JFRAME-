package Lista_Libro;

import static javax.swing.JOptionPane.showMessageDialog;

public class Lista {

	public Nodo fin, inicio;

	public Lista() {
		fin = inicio = null;
	}

	public boolean listaVacia() {
		return inicio == null && fin == null;
	}

	public void insertar(Libro a) {
		if (inicio == null) {
			inicio = fin = new Nodo(a);
		} else {
			fin.setSig(new Nodo(a));
			fin.getSig().setAnt(fin);
			fin = fin.getSig();
			fin.setSig(inicio);
			inicio.setAnt(fin);
		}
	}

	public Nodo Existe(String ISBN) {
		for (Nodo i = inicio; i != null; i = i.getSig()) {
			if (i.getA().getISBN().equalsIgnoreCase(ISBN)) {
				return i;
			}
		}
		return null;
	}

	public boolean Eliminar(String ISBN) {
		Nodo b = Existe(ISBN);
		if (b == null) {
			javax.swing.JOptionPane.showMessageDialog(null, "El Libro No Existe");
			return false;
		}
		if (b == inicio) {
			inicio = inicio.getSig();
		} else {
			b.setSig(b.getSig().getSig());
		}
		return true;
	}
}

