package Lista_Libro;

public class Nodo {
    public Libro a;
     public Nodo sig,ant;

    public Nodo(Libro a) {
        this.a = a;
    }

    public Libro getA() {
        return a;
    }

    public void setA(Libro a) {
        this.a = a;
    }

    public Nodo getSig() {
        return sig;
    }

    public void setSig(Nodo sig) {
        this.sig = sig;
    }

    public Nodo getAnt() {
        return ant;
    }

    public void setAnt(Nodo ant) {
        this.ant = ant;
    }
     
}
