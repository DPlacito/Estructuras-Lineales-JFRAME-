/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Menu_Principal;

import static javax.swing.JOptionPane.*;

/**
 *
 * @author Daniel Arturo Gonzalez Placito
 */
public class ColaCircular {
 public int tam , inicio, fin , A[], cont;

    public ColaCircular() {
    }

    public ColaCircular(int tam) {
        this.tam = tam;
        inicio =0;
        fin =-1;
        cont=0;
        A = new int [tam];
    }
    public boolean vacia(){
    return (cont==0);
    }

    public
    int getInicio() {
        return inicio;
    }

    public
    int getFin() {
        return fin;
    }

    public
    int getA() {
        return A[fin];
    }
    public boolean llena(){
     return (cont==tam);
    }
    public Object entrada (int e){
        if(!llena()){
        fin++;
        if(fin==tam)
        {
            fin =0;
        }
             A[fin]=e;
            cont++;
             return A[fin];
        }
        else{
        return null;
        }
    }
    public Object salida(){
    if(!vacia()){
    int temp = A[inicio];
    A[inicio++]= 0;
    if(inicio==tam)
    {inicio=0;}
    cont--;
    return temp;
    }
    else{
    return null;
    }
    }
    public void verCola() {
        String cad = "";
        for (int i = 0; i < tam; i++) {
            cad = cad + "[" + A[i] + "]\n";
        }
        showMessageDialog(null, cad);
    }
    public static void main(String[] args) {
       ColaCircular c = new ColaCircular(4);
         c.verCola();
         c.salida();
         c.entrada(1);
         c.entrada(2);
         c.entrada(3);
         c.entrada(4);
         c.verCola();
         c.entrada(7);
         c.verCola();

    }
}
