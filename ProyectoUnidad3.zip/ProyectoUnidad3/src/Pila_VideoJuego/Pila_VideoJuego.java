package Pila_VideoJuego;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Daniel Arturo Gonzalez Placito
 */
public class Pila_VideoJuego {

    public int tamaño;
    public int tope;
    public VideoJuego A[];

    public int getTamaño() {
        return tamaño;
    }

    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }

    public int getTope() {
        return tope;
    }

    public void setTope(int tope) {
        this.tope = tope;
    }

    public VideoJuego[] getL() {
        return A;
    }

    public void setL(VideoJuego[] A) {
        this.A = A;
    }

    public Pila_VideoJuego() {
        tamaño = 0;
        tope = -1;

    }

    public Pila_VideoJuego(int t) {
        tamaño = t;
        tope = -1;
        A = new VideoJuego[tamaño];
    }

    public boolean esVacia() {
        return tope == -1;
    }

    public boolean esLlena() {
        return tope == tamaño - 1;
    }


    public void meter(String titulo, String genero, float precio) {
        if (!esLlena()) {
            A[++tope] = new VideoJuego(titulo, genero, precio);
        } else {
            javax.swing.JOptionPane.showMessageDialog(null, "pila llena");
        }
    }

    public VideoJuego sacar() {
        VideoJuego l = null;
        if (!esVacia()) {
            return A[tope--];
        } else {
            javax.swing.JOptionPane.showMessageDialog(null, "pila vacia");
        }
        return l;
    }
}
