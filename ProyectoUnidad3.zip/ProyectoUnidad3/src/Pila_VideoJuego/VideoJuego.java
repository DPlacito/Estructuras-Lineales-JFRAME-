package Pila_VideoJuego;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Daniel Arturo Gonzalez Placito 
 */
public class VideoJuego {
 public String  titulo, genero;
    public float precio;

    public VideoJuego() {
    }

    public VideoJuego(String titulo, String genero, float precio) {
  
        this.titulo = titulo;
        this.genero = genero;
        this.precio = precio;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "VideoJuego{" + "titulo=" + titulo + ", genero=" + genero + ", precio=" + precio + '}';
    }
    
}
